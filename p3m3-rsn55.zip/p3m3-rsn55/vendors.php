<!DOCTYPE html>
<html>

<head>
  <title> Ithaca Apple Fest 2017 </title>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">

  <link rel="stylesheet" type="text/css" href="styles/all.css" media="all"/>
  <script type="text/javascript" src="scripts/jquery-3.2.1.js"></script>
  <script type="text/javascript" src="scripts/site.js"></script>
</head>

<body>

<?php include "includes/navigation.php"; ?>

  <div class="vendor-flex">

    <div class="feature">
      <h3>Featured</h3>
      <p>Littletree Orchards will return with their famous apple cider doughnuts — we’ve seen lines at least 50 people deep waiting to purchase this sweet treat — and Laughing Goat Fiber Farm will once again bring its adorable goats to pet and their fiber to feel. Robbie’s Produce is also making a return visit with its fresh picked and juicy produce, plus it’ll be making beautiful, customized garden and floral arrangements to honor Apple Harvest Festival’s 35th anniversary.
        Festival newcomer Monks on the Commons is preparing a fall feast, serving freshly baked doughnuts with maple cream and brown sugar bacon, a butternut squash bisque pork sandwich made with cardamom-spiced pork, cinnamon butter toasted roll and apple-blackcurrant chutney, and Trini Style is returning with a savory brown stew chicken, curry chicken and veggies, spinach fritters and roti and rice.
        Puccoon Raccoon, a Rochester-based jewelry maker, will feature its line of unique engagement/wedding rings, fun charms, stunning necklaces, and dazzling earrings while Katie Van Design will be showcasing its original coloring books and eye-catching prints and Skelly Chic will be selling its one-of-a-kind skeleton sculptures and stationary.
        <figure >
          <img id="vendorPic" src="images/apple10.jpg" alt="picture from apple fest">
          <p class="source"> Source: Andrew Halpern, https://www.flickr.com/photos/106103661@N02/albums/with/72157657274645113</p>
        </figure>
      </div>

      <div class="all-flex">

        <div class="craft">
          <h3>Craft</h3>
          <ul>
            <li>Kissed by the Sun Spice Company</li>
            <li>Laurel O'Brien Jewelry</li>
            <li>The Chop Shop Studio Chopshop Studio</li>
            <li>Elizabeth Lassing Jewelry</li>
            <li>Luna Sea Trading</li>
            <li>Golden Hand Design Golden Hand Designs</li>
            <li>Wise Guyz Gadgets</li>
            <li>Dave's Art Den</li>
            <li>Riverstone Jewelry</li>
            <li>Colin D. Young Photography</li>
            <li>Helena's Organic Garden</li>
            <li>Weathertop Farm</li>
            <li>What The Fork</li>
            <li>HRLMScreations</li>
          </ul>
        </div>
        <div class="food">
          <h3>Food</h3>
          <ul>
            <li>Silo Food Truck</li>
            <li>Let's Roll Gourmet Egg Rolls</li>
            <li>Kettle Corn Shoppe</li>
            <li>New Delhi Diamonds Indian Restaurant</li>
            <li>Trini Style </li>
            <li>OmNomNomelettes</li>
            <li>Sangam Indian Cuisine</li>
            <li>Gourmet Caramel Apples </li>
            <li>Ithaca Congo Square Market</li>
            <li>Lao Village</li>
            <li>PDR Catering </li>
            <li>On The Street</li>
            <li>B&B Kettle Korn</li>
            <li>Thai Basil</li>
          </ul>
        </div>
        <div class="farmer">
          <h3>Farmer</h3>
          <ul>
            <li>Blackduck Cidery</li>
            <li>Student Society of Horticulture(SoHo) </li>
            <li>The Piggery</li>
            <li>A J Teeter Farm </li>
            <li>Eve's Cidery</li>
            <li>Finger Lakes Cider House</li>
            <li>Baker's Acres</li>
            <li>Schoolyard Sugarbush</li>
            <li>Indian Creek Farm</li>
            <li>Robbies Produce</li>
            <li>Littletree Orchards (Apple Cider Donuts) </li>
            <li>Little Grey Bakery</li>
            <li>CreamCycle</li>
            <li>Ryan William Vineyard</li>
          </ul>
        </div>

      </div>
    </div>
    <div class="apply">
      <p><a href="http://downtownithaca.com/ithaca-events/2017%20Apple%20Harvest%20Festival%20Applications" class="link" target="_blank">Apply to be a vendor</a></p>
    </div>
    <p class="source"> Source: http://www.downtownithaca.com/ithaca-events/35th%20Apple%20Harvest%20Festival%20Presented%20by%20Tompkins<p>



    </body>

    </html>
