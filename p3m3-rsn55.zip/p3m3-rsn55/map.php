<!DOCTYPE html>
<html>

<head>
  <title> Ithaca Apple Fest 2017 </title>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <script type="text/javascript" src="scripts/jquery-3.2.1.js"></script>
  <script type="text/javascript" src="scripts/site.js"></script>
  <link rel="stylesheet" type="text/css" href="styles/all.css" media="all"/>
</head>

<body>

  <?php include "includes/navigation.php"; ?>

  <figure>
    <a href="images/applefestMap.jpg" target="_blank"><img class="map" src="images/applefestMap.jpg" alt="map of apple fest"></a>
    <p class="source"> Source: http://www.downtownithaca.com/local/file_upload/images/Apple%20Harvest%20Map%202016.jpg </p>
  </figure>

</body>

</html>
