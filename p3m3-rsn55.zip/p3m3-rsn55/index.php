<!DOCTYPE html>
<html>

<head>
  <title> Ithaca Apple Fest 2017 </title>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <script type="text/javascript" src="scripts/jquery-3.2.1.js"></script>
  <script type="text/javascript" src="scripts/site.js"></script>
  <link rel="stylesheet" type="text/css" href="styles/all.css" media="all"/>
</head>

<body>


<?php include "includes/navigation.php"; ?>


  <div id="homePic">
    <p class="source">Source: http://www.downtownithaca.com/ithaca-events/35th%20Apple%20Harvest%20Festival%20Presented%20by%20Tompkins </p>
  </div>
</body>

</html>
