$(document).ready(function () {


  // whenever the user tries to submit the form
  $("#mainForm").on("submit", function() {
    formValid = true;

    var letters = /^[A-Za-z]+$/;
    if($("#firstName").value.match(letters) && $("#firstName").prop("validity").valid) {
      firstNameValid = true;
    }else {
      firstNameValid = false;
    }
    if($("#lastName").value.match(letters) && $("#lastName").prop("validity").valid) {
      lastNameValid = true;
    }else {
      lastNameValid = false;
    }

    emailIsValid = $("#userEmail").prop("validity").valid;
    req1isValid = $("#req1").prop("validity").valid;
    req2isValid = $("#req2").prop("validity").valid;
    selectStudentIsValid = $("#selectStudent").prop("validity").valid;
    attendIsValid = $("#attend").prop("validity").valid;
    hearIsValid = $("#hear").prop("validity").valid;
    vendorIsValid = $("#vendorType").prop("validity").valid;

    if(hearIsValid) {
      // hide the error
      $("#hearError").hide();
    } else { // (otherwise, if the first name field is empty)
      // show the error
      $("#hearError").show();
      // and don’t let the user submit the form
      formValid = false;
    }
    if(vendorIsValid) {
      // hide the error
      $("#vendorError").hide();
    } else { // (otherwise, if the first name field is empty)
      // show the error
      $("#vendorError").show();
      // and don’t let the user submit the form
      formValid = false;
    }

    if(attendIsValid) {
      // hide the error
      $("#attendError").hide();
    } else { // (otherwise, if the first name field is empty)
      // show the error
      $("#attendError").show();
      // and don’t let the user submit the form
      formValid = false;
    }
    if(selectStudentIsValid) {
      // hide the error
      $("#selectStudentError").hide();
    } else { // (otherwise, if the first name field is empty)
      // show the error
      $("#selectStudentError").show();
      // and don’t let the user submit the form
      formValid = false;
    }
    if(req1isValid) {
      // hide the error
      $("#req1Error").hide();
    } else { // (otherwise, if the first name field is empty)
      // show the error
      $("#req1Error").show();
      // and don’t let the user submit the form
      formValid = false;
    }
    if(req2isValid) {
      // hide the error
      $("#req2Error").hide();
    } else { // (otherwise, if the first name field is empty)
      // show the error
      $("#req2Error").show();
      // and don’t let the user submit the form
      formValid = false;
    }

    // if the first name field is valid (has text in it),
    if(firstNameIsValid) {
      // hide the error
      $("#fnameError").hide();
    } else { // (otherwise, if the first name field is empty)
      // show the error
      $("#fnameError").show();
      // and don’t let the user submit the form
      formValid = false;
    }
    // Validation for other fields here

    if(emailIsValid) {
      // hide the error
      $("#emailError").hide();
    } else { // (otherwise, if the first name field is empty)
      // show the error
      $("#emailError").show();
      // and don’t let the user submit the form
      formValid = false;
    }

    if(lastNameIsValid) {
      // hide the error
      $("#lnameError").hide();
    } else { // (otherwise, if the first name field is empty)
      // show the error
      $("#lnameError").show();
      // and don’t let the user submit the form
      formValid = false;
    }

    // if the form is valid, let the user submit it; otherwise, block submission
    return formValid;
  });



});
