$(document).ready(function () {

  $("#why").hover( function() {

    $("#explanation").toggle();
  });
});
