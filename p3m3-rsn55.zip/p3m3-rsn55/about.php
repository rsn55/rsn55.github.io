<!DOCTYPE html>
<html>

<head>
  <title> Ithaca Apple Fest 2017 </title>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <script type="text/javascript" src="scripts/jquery-3.2.1.js"></script>
  <script type="text/javascript" src="scripts/site.js"></script>
  <link rel="stylesheet" type="text/css" href="styles/all.css" media="all"/>
</head>

<body>

<?php include "includes/navigation.php"; ?>

  <div id="about-flex">
    <div id="photos1">
      <figure>
        <img class="aboutPic" src="images/apple1.jpg" alt="picture from apple fest">

      </figure>

      <figure>
        <img class="aboutPic" src="images/apple6.jpg" alt="picture from apple fest">

      </figure>

      <figure>
        <img class="aboutPic" src="images/apple3.jpg" alt="picture from apple fest">
        <p class="source"> Source for all images: Andrew Halpern, https://www.flickr.com/photos/106103661@N02/albums/with/72157657274645113 </p>
      </figure>
    </div>
    <div id="pagebody">

      <p> This family-friendly, community tradition will take place Friday, Sept 29, noon to 6 p.m. and from 10 a.m. to 6 p.m. both Saturday, Sept. 30 and Sunday, Oct. 1. Now celebrating its 35th year, this highly anticipated celebration will feature fresh local foods, handmade crafts, games, giveaways, and live performances on and around the Ithaca Commons pedestrian mall, 202 East State St., Ithaca.

        More than 20 local farmers will be selling many varieties of apples, cider, maple products, and other delectable seasonal produce and baked goods. More than 20 different food vendors will be serving delicious dishes to suit every palate.
        In addition to the farmers and foods, nearly 70 craft vendors from all over the community and the nation will converge in downtown Ithaca to sell hundreds of handmade items. Throughout Saturday and Sunday, we will have a full lineup of acts set to take the Bernie Milton Pavilion stage.
        “Apple Harvest Festival is one of those community events that you simply don’t want to miss. It’s the perfect opportunity to sample all of the yummy fall foods and tasty beverages that this region is known for, and it’s a wonderful introduction to downtown for those who have never been here before,” says Tatiana Sy, special events director for the DIA.

      </p>
      <p class="source"> Source: https://downtownith.com/<p>
      </div>
      <div id="photos2">
        <figure>
          <img class="aboutPic" src="images/apple4.jpg" alt="picture from apple fest">

        </figure>

        <figure>
          <img class="aboutPic" src="images/apple5.jpg" alt="picture from apple fest">

        </figure>

        <figure>
          <img class="aboutPic" src="images/apple2.jpg" alt="picture from apple fest">
          <p class="source"> Source for all images: Andrew Halpern, https://www.flickr.com/photos/106103661@N02/albums/with/72157657274645113 </p>
        </figure>
      </div>
    </div>
  </body>

  </html>
