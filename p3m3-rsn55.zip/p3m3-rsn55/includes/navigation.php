  <div class="header">
    <div id="date-flex">
      <p class="headerSides">September 29 - <br>October 1</p>
    </div>
    <div id="center-flex">
    <h1><a href="index.php">ITHACA APPLE FEST 2017</a></h1>
    <nav class="menu">
      <ul>
        <li><a href="about.php">ABOUT</a></li>

        <li class="dot">&#9672;</li>
        <li><a href="plan.php">PLAN</a></li>
        <li class="dot">&#9672;</li>
        <li><a href="vendors.php">VENDORS</a></li>
        <li class="dot">&#9672;</li>
        <li><a href="map.php">MAP</a></li>
      </ul>
    </nav>
  </div>
    <div id="survey-flex">
    <p class="headerSides"><a href="feedback.php">Have 5 minutes <br>to spare? Find out <br>how you could<br> win $50!</a></p>
  </div>
  </div>
