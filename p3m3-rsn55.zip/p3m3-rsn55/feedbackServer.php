<?php
$firstName = $_REQUEST["firstName"];
$lastName = $_REQUEST["lastName"];
$email = $_REQUEST["userEmail"];
$selectStudent = $_REQUEST["selectStudent"];
$attend = $_REQUEST["attend"];
$hear = $_REQUEST["hear"];
$vendorType = $_REQUEST["vendorType"];
$excited = $_REQUEST["excited"];
$future = $_REQUEST["future"];
$difficult = $_REQUEST["difficult"];
$addition = $_REQUEST["addition"];

$HIDDEN_ERROR_CLASS = "hiddenError";

// Get information about the form
$submit = $_REQUEST["submit"];

if (isset($submit)) {
  $HIDDEN_ERROR_CLASS = "hiddenError";

  // if the first name field is not empty:

  if ( !empty($firstName) && ctype_alpha(str_replace(' ', '', $firstName)) ) {
    $firstNameValid = true;
  } else {
    $firstNameValid = false;
  }

  // if the last name field is not empty:

  if ( !empty($lastName) && ctype_alpha(str_replace(' ', '', $lastName))) {
    $lastNameValid = true;
  } else {
    $lastNameValid = false;
  }

  // Handle email
  $isEmailEmpty = empty($email);
  $isEmailAddress = filter_var($email, FILTER_VALIDATE_EMAIL);
  if ( !$isEmailEmpty && $isEmailAddress ) {
    $emailValid = true;
  } else {
    $emailValid = false;
  }

  // Select Student
  if ( $selectStudent != '' ) {
    $selectStudentValid = true;
  } else {
    $selectStudentValid = false;
  }

  // Attend
  if ( $attend != '' ) {
    $attendValid = true;
  } else {
    $attendValid = false;
  }
  // Hear
  if ( $hear != '' ) {
    $hearValid = true;
  } else {
    $hearValid = false;
  }

  // Vendor
  if ( $vendorType != '' ) {
    $vendorValid = true;
  } else {
    $vendorValid = false;
  }

  //excited text area
  if ( strlen($excited)>= 30) {
    $excitedValid = true;
  } else {

    $excitedValid = false;
  }
  // future text area
  if ( strlen($future)>= 30) {
    $futureValid = true;
  } else {
    $futureValid = false;
  }

  $formValid = $firstNameValid && $emailValid && $lastNameValid &&
  $selectStudentValid && $attendValid && $hearValid && $vendorValid &&
  $excitedValid && $futureValid;
  // if valid, allow submission
  if ($formValid) {
    session_start();
    $_SESSION["firstName"] = $firstName;
    session_start();
    $_SESSION["lastName"] = $lastName;
    session_start();
    $_SESSION["email"] = $email;
    // redirect to submitted.php
    header("Location: submitted.php");
    return;
  }
}
else {
  // no form submitted
  $firstNameValid = true;
  $lastNameValid = true;
  $emailValid = true;
  $selectStudentValid = true;
  $attendValid = true;
  $hearValid = true;
  $vendorValid = true;
  $excitedValid = true;
  $futureValid = true;

}

?>

<!DOCTYPE html>
<html>

<head>
  <title> Ithaca Apple Fest 2017 </title>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <script type="text/javascript" src="scripts/jquery-3.2.1.js"></script>

  <!-- Load validation -->
  <!-- <script src="scripts/clientValidation.js" type="text/javascript"></script> -->
  <script src="scripts/site.js" type="text/javascript"></script>
  <link rel="stylesheet" type="text/css" href="styles/all.css" media="all"/>
</head>

<body>

  <?php include "includes/navigation.php"; ?>

  <p id="feedback-descript">We want your feedback!
    Take this short survey and your name will be entered into
    a drawing to win a $50 Amazon gift card!</p>
    <p id=confidential> Please note that
      the information you submit here is confidential and used only
      for research purposes. </p>

      <p id="requiredPar">
        <span class="star"> *</span> These elements are required.
      </p>


      <form method="post" action="feedbackServer.php" id="mainForm" novalidate>
        <div class="labelAndInputHolder">
          <div class="labelHolder">
            <label for="firstName">First Name: </label>
            <span class="star"> *</span>
            <span class="errorContainer <?php if ($firstNameValid) { echo($HIDDEN_ERROR_CLASS);} ?>" id="fnameError">
              Must submit a valid name.
            </span>
          </div>
          <div class="inputHolder">
            <input value="<?php echo($firstName);?>" id="firstName" name="firstName" required>
          </div>
          <!-- this error message is hidden by default -->

        </div>

        <div class="labelAndInputHolder">
          <div class="labelHolder">
            <label for="firstName">Last Name: </label>
            <span class="star"> *</span>
            <span class="errorContainer <?php if ($lastNameValid) { echo($HIDDEN_ERROR_CLASS);} ?>" id="lnameError">
              Must submit a valid name.
            </span>
          </div>
          <div class="inputHolder">
            <input value="<?php echo($lastName);?>" id="lastName" name="lastName" required>
          </div>

        </div>

        <div class="labelAndInputHolder">
          <div class="labelHolder">
            <label for="firstName">Email: </label>
            <span class="star"> *</span>
            <span class="errorContainer <?php if ($emailValid) { echo($HIDDEN_ERROR_CLASS);} ?>" id="emailError">
              Must submit a valid email.
            </span>
            <span id="why"> Why? </span>
            <span id="explanation"> We need your email to send the gift card if you win.</span>


          </div>
          <div class="inputHolder">
            <input value="<?php echo($email);?>" type="email" id="userEmail" name="userEmail" required>
          </div>

        </div>

        <p>Are you a full-time student? <span class="star"> *</span>
          <span class="errorContainer <?php if ($selectStudentValid) { echo($HIDDEN_ERROR_CLASS);} ?>" id="selectStudentError">
            Must select an option.
          </span></p>
          <select value="<?php echo($selectStudent);?>" id="selectStudent" name="selectStudent" required>
            <option selected value="">Select</option>
            <option value="Student"<?php echo($selectStudent=='Student'?' selected="selected"':'');?>>Yes</option>
            <option value="nonStudent"<?php echo($selectStudent=='nonStudent'?' selected="selected"':'');?>>No</option>


          </select>


          <p>Have you attended Apple Fest before? <span class="star"> *</span>
            <span class="errorContainer <?php if ($attendValid) { echo($HIDDEN_ERROR_CLASS);} ?>" id="attendError">
              Must select an option.
            </span></p>
            <select value="<?php echo($attend);?>" id="attend" name="attend" required>
              <option selected value="">Select</option>
              <option value="Yes"<?php echo($attend=='Yes'?' selected="selected"':'');?>>Yes</option>
              <option value="No"<?php echo($attend=='No'?' selected="selected"':'');?>>No</option>
            </select>


            <p>How did you first hear about Apple Fest? <span class="star"> *</span>
              <span class="errorContainer <?php if ($hearValid) { echo($HIDDEN_ERROR_CLASS);} ?>" id="hearError">
                Must select an option.
              </span></p>
              <select value="<?php echo($hear);?>" id="hear" name="hear" required>
                <option selected value="">Select</option>
                <option value="Facebook"<?php echo($hear=='Facebook'?' selected="selected"':'');?>>Facebook</option>
                <option value="Poster"<?php echo($hear=='Poster'?' selected="selected"':'');?>>Poster</option>
                <option value="WordofMouth"<?php echo($hear=='WordofMouth'?' selected="selected"':'');?>>Friend</option>
                <option value="search"<?php echo($hear=='search'?' selected="selected"':'');?>>Search Engine</option>
                <option value="other"<?php echo($hear=='other'?' selected="selected"':'');?>>Other</option>
              </select>


              <p>What do you look forward to the most? <span class="star"> *</span>
                <span class="errorContainer <?php if ($vendorValid) { echo($HIDDEN_ERROR_CLASS);} ?>" id="vendorError">
                  Must select an option.
                </span></p>
                <select value="<?php echo($vendorType);?>" id="vendorType" name="vendorType" required>
                  <option selected value="">Select</option>
                  <option value="Food"<?php echo($vendorType=='Food'?' selected="selected"':'');?>>Food Vendors</option>
                  <option value="Craft"<?php echo($vendorType=='Craft'?' selected="selected"':'');?>>Craft Vendors</option>
                  <option value="Farmer"<?php echo($vendorType=='Farmer'?' selected="selected"':'');?>>Farmers</option>
                  <option value="Performers"<?php echo($vendorType=='Performers'?' selected="selected"':'');?>>Performers</option>
                </select>



                <p class="marg">What else makes you excited to attend Apple Fest? <span class="star"> *</span>
                  <span class="errorContainer <?php if ($excitedValid) { echo($HIDDEN_ERROR_CLASS);} ?>" id="req1Error">
                    30 character minimum
                  </span>
                </p>
                <div>
                  <label for="excited"></label>
                  <textarea id="req1" name="excited" minlength="30" required><?php echo($excited);?></textarea>
                </div>



                <p class="marg">What would you like to see at Apple Fest in the future? <span class="star"> *</span>
                  <span class="errorContainer <?php if ($futureValid) { echo($HIDDEN_ERROR_CLASS);} ?>" id="req2Error">
                    30 character minimum
                  </span>
                </p>
                <div>
                  <label for="future"></label>
                  <textarea id="req2" name="future" minlength="30" required><?php echo($future);?></textarea>
                </div>


                <p class="marg">What, if anything, makes it difficult for you to attend? </p>
                <div>
                  <label for="difficult"></label>
                  <textarea name= "difficult" id="difficult" name="user_message"><?php echo($difficult);?></textarea>
                </div>



                <p class="marg">Additional Comments:</p>
                <div>
                  <label for="addition"></label>
                  <textarea name="addition" id="addition" name="user_message"><?php echo($addition);?></textarea>
                </div>

                <div class="button">
                  <button type="submit" value="Submit" name="submit">Submit</button>
                </div>
              </form>

              <p id="requiredPar">
                <span class="star"> *</span> These elements are required.
              </p>




            </body>
            </html>
