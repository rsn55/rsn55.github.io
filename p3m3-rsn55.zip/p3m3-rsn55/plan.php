<!DOCTYPE html>
<html>

<head>
  <title> Ithaca Apple Fest 2017 </title>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <script type="text/javascript" src="scripts/jquery-3.2.1.js"></script>
  <script type="text/javascript" src="scripts/site.js"></script>
  <link rel="stylesheet" type="text/css" href="styles/all.css" media="all"/>
</head>

<body>

<?php include "includes/navigation.php"; ?>

  <div class="content-wrap">
    <div class="events">

      <table>
        <colgroup>
          <col>
          <col>
          <col>
          <col>
        </colgroup>

        <tr>
          <th id="timeHead">Time</th>
          <th>Friday 9/29</th>
          <th>Saturday 9/30</th>
          <th>Sunday 10/1</th>
        </tr>
        <tr class="open">
          <td class="time"></td>
          <td></td>
          <td>10am Opening</td>
          <td>10am Opening</td>
        </tr>
        <tr class="perf">
          <td class="time">10-10:45 AM</td>
          <td></td>
          <td>IC Voicestream</td>
          <td>Mighty Jet Band</td>
        </tr>
        <tr class="perf">
          <td class="time">11-11:45 AM</td>
          <td></td>
          <td>Danza Romani</td>
          <td>Sixteen Feathers</td>
        </tr>
        <tr class="perf">
          <td class="time">12-12:45 PM</td>
          <td class="open">12pm Opening</td>
          <td>Vitamin L</td>
          <td>Mirage Belly Dancers</td>
        </tr>
        <tr class="perf">
          <td class="time">1-1:45 PM</td>
          <td></td>
          <td>Vee Da Bee</td>
          <td>Mijail Martinez </td>
        </tr>
        <tr class="perf">
          <td class="time">1:45-2 PM</td>
          <td></td>
          <td id="giveaway">GIVEAWAYS</td>
          <td></td>
        </tr>
        <tr class="perf">
          <td class="time">2-2:50 PM</td>
          <td></td>
          <td>Sunny Weather</td>
          <td>Diana Leigh Quintet</td>
        </tr>
        <tr class="perf">
          <td class="time">3-3:45 PM</td>
          <td></td>
          <td>WICB</td>
          <td>A Bite of Science</td>
        </tr>
        <tr class="perf">
          <td class="time">4-4:45 PM</td>
          <td></td>
          <td>Dapper Dan</td>
          <td>IC Jazz Ensemble</td>
        </tr>
        <tr class="perf">
          <td class="time">5-6 PM</td>
          <td></td>
          <td>Papa Muse</td>
          <td>NEO Project</td>
        </tr>
        <tr id="close">
          <td class="time"></td>
          <td>6pm Closing</td>
          <td>6pm Closing</td>
          <td>6pm Closing</td>
        </tr>
      </table>
      <p id="stage">All live performances listed here take place on the Bernie Milton Stage.</p>
      <div id="tablePhoto">
        <figure>
          <img class="tablepic" src="images/apple7.jpg" alt="picture from apple fest">

        </figure>

        <figure>
          <img class="tablepic" src="images/apple8.jpg" alt="picture from apple fest">

        </figure>

        <figure>
          <img class="tablepic" src="images/apple9.jpg" alt="picture from apple fest">
          <p class="source"> Source for all images: Andrew Halpern, https://www.flickr.com/photos/106103661@N02/albums/with/72157657274645113 </p>
        </figure>
      </div>
    </div>
    <div class="transport">
      <h3>Location</h3>
      <p>The Ithaca Commons: 202 East State St, Ithaca, NY</p>

      <figure>
        <img class="tablepic" src="images/commons.jpg" alt="picture of the commons">
        <div id="shortSource">
          <p class="source"> Source: http://whcuradio.com/news/025520-myrick-ithaca-must-invest-in-commons-maintenance/</p>
        </div>
      </figure>
      <h3>TCAT Route Suggestions</h3>
      <p><span class="bold">Between Cornell and The Commons:</span> Routes 10, 21, 30, 31, 32, 51, 65</p>
      <p><span class="bold">Between Ithaca College and The Commons:</span> Route 11</p>
      <p>View the <a class="link" href="https://www.tcatbus.com/" target="_blank">TCAT website</a> for more options and specific times or download the app, Ride14850.</p>
      <h3>Parking</h3>
      <p>Parking for the festival will be available in the Green, Seneca, and Cayuga street garages for $5. You can find these locations easily on the <a class="link" href="map.html">map</a>.</p>

      <p class="source"> Source: http://www.downtownithaca.com/ithaca-events/35th%20Apple%20Harvest%20Festival%20Presented%20by%20Tompkins<p>

      </div>
    </div>
  </body>

  </html>
