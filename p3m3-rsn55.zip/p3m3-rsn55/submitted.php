<?php
session_start();
$firstName = $_SESSION["firstName"];
?>
<?php
session_start();
$lastName = $_SESSION["lastName"]
?>
<?php
session_start();
$email = $_SESSION["email"];
?>


<!DOCTYPE html>
<html>

<head>
  <title> Ithaca Apple Fest 2017 </title>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">

  <link rel="stylesheet" type="text/css" href="styles/all.css" media="all"/>
  <script type="text/javascript" src="scripts/jquery-3.2.1.js"></script>
  <script type="text/javascript" src="scripts/site.js"></script>
</head>

<body>

  <?php include "includes/navigation.php"; ?>
  <p id="thankyou"><?php echo($firstName . " " . $lastName); ?>, thanks for your contribution to Apple Fest! We will e-mail you the results of the drawing shortly at <?php echo($email); ?>.</p>
</body>
</html>
